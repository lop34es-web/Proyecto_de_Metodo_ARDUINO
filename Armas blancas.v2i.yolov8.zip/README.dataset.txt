# Armas blancas > 2025-03-12 3:37pm
https://universe.roboflow.com/imagenes-j1d5w/armas-blancas-jn1ae

Provided by a Roboflow user
License: CC BY 4.0

